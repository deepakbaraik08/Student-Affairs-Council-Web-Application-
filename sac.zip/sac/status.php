<?php
  $con=mysqli_connect("localhost","root","anvesha","SAC");
  if(mysqli_connect_errno())
  {echo "failed to connect:".mysqli_connect_error();}
  $c_no=$_POST['cno'];
   echo "<h3 align='center'>Complain Details</h3>";
  echo "<form>";
  echo "<table summary='Summary Here' cellpadding='0' cellspacing='0'>
        <thead>
          <tr>
            <th colspan='3'>Details</th>
          </tr>
        </thead>";
  $result=mysqli_query($con,"SELECT * FROM comp_status where comp_id='$c_no'");
  if(!($result))
  {die('Error:'.mysqli_error($con));} 
  while($row=mysqli_fetch_array($result))
  {
    echo "<tbody>
          <tr class='dark'>";
    echo "<td>".$row[1]."</td>";
    echo "<td>".$row[2]."</td>";
    echo "<td>".$row[3]."</td>";
    echo "</tr>";
  }
  echo "<tr><td><input type='text' name='id' placeholder='Enter Candidate Id'></td><td><input type='submit' value='delete'></td></tr>";
  echo "<tr><td colspan='2' align='center'><button type='submit' formaction='front.php'>Back</button></td></tr>";
  echo "</table>";
  echo "</form>";
?>
