<!DOCTYPE html>

<html>
<?php
        $con=mysqli_connect("localhost","root","reality","db_sac");
        if(mysqli_connect_errno($con))
        {
                echo "Connection failed".mysqli_connect_error();
        }

        $user_id     =     mysqli_real_escape_string($con , $_POST['user_id']);
        $category       =     mysqli_real_escape_string($con , $_POST['category']);
        $description    =     mysqli_real_escape_string($con , $_POST['description']);

        $sql= "INSERT INTO suggestion(user_id,category,description)
                values ('$user_id','$category','$description')";

        if (!mysqli_query($con,$sql))
        {
                die('Error: ' . mysqli_error($con));
        }
        header('location:suggestion1.php');        


        mysqli_close($con);
?>
       

</body>
</html>
