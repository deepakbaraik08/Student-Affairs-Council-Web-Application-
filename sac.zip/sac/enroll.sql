-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2014 at 02:23 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sac`
--

-- --------------------------------------------------------

--
-- Table structure for table `enroll`
--

CREATE TABLE IF NOT EXISTS `enroll` (
  `std_id` varchar(10) NOT NULL,
  `name` char(70) NOT NULL,
  `course` char(30) NOT NULL,
  `year` int(3) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `event_id` varchar(10) NOT NULL,
  `status` char(20) NOT NULL,
  `enroll_id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`enroll_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1007 ;

--
-- Dumping data for table `enroll`
--

INSERT INTO `enroll` (`std_id`, `name`, `course`, `year`, `email`, `phone`, `event_id`, `status`, `enroll_id`, `password`) VALUES
('M130311CA', 'Abhishek Kumar', 'mca', 2, 'abhishek@gmail.com', '9446995809', '1', 'Enrolled', 1000, 'abhishek'),
('M130291CA', 'Shubham Singh', 'mca', 2, 'shubham@gmail.com', '9446995809', '1', 'Enrolled', 1003, 'shubham'),
('m130287ca', 'Vikas Singh', 'mca', 2, 'vikku@gmail.com', '987654321', '1', 'Enrolled', 1004, 'vikku'),
('M130288CA', 'Deepak Baraik', 'mca', 2, 'baraikd@gmail.com', '987654321', '2', 'Enrolled', 1005, 'baraik'),
('M130288CA', 'Deepak Baraik', 'mca', 2, 'baraikd@gmail.com', '987654321', '2', 'Enrolled', 1006, 'baraik');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
