<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="EN" lang="EN" dir="ltr">
<head profile="http://gmpg.org/xfn/11">
<title>Educational | Full Width</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" href="styles/layout.css" type="text/css" />
<script type="text/javascript" src="scripts/jquery-1.4.1.min.js"></script>
<script type="text/javascript" src="scripts/jquery.slidepanel.setup.js"></script>
</head>
<body>
<div class="wrapper col0">
  <div id="topbar">
    <div id="slidepanel">
      <div class="topbox">
        <h2>About SAC</h2>
        <p>Students are the life and blood of any educational institution. They form the vast majority of the campus inmates and the success of any institution depends, to a large exten, on the proper administration of the requirement of the student community.</p>
        <p class="readmore"><a href="images/demo/SAC.pdf">Continue Reading &raquo;</a></p>
      </div>
      <div class="topbox">
        <h2>SAC Login Here</h2>
        <form action="#" method="post">
          <fieldset>
            <legend>SAC Login Form</legend>
            <label for="sac">Username:
              <input type="text" name="sacname" id="sacname" value="" />
            </label>
            <label for="sacpass">Password:
              <input type="password" name="sacpass" id="sacpass" value="" />
            </label>
            <label for="sacremember">
              <input class="checkbox" type="checkbox" name="sacremember" id="sacremember" checked="checked" />
              Remember me</label>
            <p>
              <input type="submit" name="saclogin" id="saclogin" value="Login" />
              &nbsp;
              <input type="reset" name="sacrreset" id="sacreset" value="Reset" />
            </p>
          </fieldset>
        </form>
      </div>
      <div class="topbox last">
        <h2>Pupils Login Here</h2>
        <form action="#" method="post">
          <fieldset>
            <legend>Pupils Login Form</legend>
            <label for="pupilname">Username:
              <input type="text" name="pupilname" id="pupilname" value="" />
            </label>
            <label for="pupilpass">Password:
              <input type="password" name="pupilpass" id="pupilpass" value="" />
            </label>
            <label for="pupilremember">
              <input class="checkbox" type="checkbox" name="pupilremember" id="pupilremember" checked="checked" />
              Remember me</label>
            <p>
              <input type="submit" name="pupillogin" id="pupillogin" value="Login" />
              &nbsp;
              <input type="reset" name="pupilreset" id="pupilreset" value="Reset" />
            </p>
          </fieldset>
        </form>
      </div>
      <br class="clear" />
    </div>
    <div id="loginpanel">
      <ul>
        <li class="left">Log In Here &raquo;</li>
        <li class="right" id="toggle"><a id="slideit" href="#slidepanel">Administration</a><a id="closeit" style="display: none;" href="#slidepanel">Close Panel</a></li>
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col1">
  <div id="header">
    <div id="">
      <a href="#"><font size='20'>National Institute of Technology, Calicut</font></a>
      <h1>Student Affair Council</h1>
    </div>
    <div class="fl_right">
      <p>Tel: 0495-228617 | Mail: sac_nitc@nitc.ac.in</p>
      </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col2">
  <div id="topnav">
    <ul>
      <li class="#"><a href="index.html">Home</a></li>

      <li class="#"><a href="abt.html">About Us</a></li>
      
      <li class="active"><a href="events.html">Events</a>
        <ul>
          <li><a href="workshop.php">Workshops</a></li>
          <li><a href="lectures.php">Lectures</a></li>
          <li><a href="clubs.html">Clubs</a></li>
          <li class="last"><a href="cultural.php">Cultural</a></li>
        </ul>
      </li>
      
      <li><a href="complain.html">Complaints</a>
      </li>
      <li><a href="suggestion.html">Suggestion</a></li>

      <li><a href="#">Contacts</a></li>

      <li><a href="#">Help Desk</a></li>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col3">
  <div id="breadcrumb">
    <ul>
      <li class="first">You Are Here</li>
      <li>&#187;</li>
      <li><a href="#">Home</a></li>
      <li>&#187;</li>
      <li><a href="#">Complaint</a></li>
      <li>&#187;</li>
      <li class="current"><a href="#">Academic</a></li>
    </ul>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col4">
  <div id="container">
    <form method="post">
    <table >
    <tr><td align="center"><center><div id="section">ENROLLMENT FORM</center></div></td></tr>
    <tr><td>
        <table summary="Summary Here" cellpadding="0" cellspacing="0">
        <thead>
          <tr>
            <th colspan="6">Please Fill Your Details</th>
          </tr>
        </thead>
        <tbody>
          <tr class="dark">
            <td>Roll No</td>
            <td colspan="6"><input type="text" name="roll" placeholder="Roll No" required></td>
          </tr>
          <tr class="light">
            <td>Full Name</td>
            <td colspan="6"><input type="text" name="name" placeholder="Enter Name" required></td>
          </tr>
          <tr class="dark">
            <td>Contact No</td>
            <td colspan="6"><input type="text" name="phone" placeholder="Enter Contact" required></td>
          </tr>
          <tr class="light">
            <td>Course</td>
            <td><input type="radio" name="course" value="btech">B.Tech</td>
            <td><input type="radio" name="course" value="mtech">M.Tech</td>
            <td><input type="radio" name="course" value="mca">MCA</td>
            <td><input type="radio" name="course" value="msc">MSc</td>
            <td><input type="radio" name="course" value="phd">Phd</td>
          </tr>
          <tr class="dark">
            <td>Email</td>
            <td colspan="6"><input type="Email" name="email" placeholder="Enter Email Id" required></td>
          </tr>
          <tr class="light">
            <td>Year</td>
            <td colspan="6"><input type="int" name="year" placeholder="Year" required></td></tr>
          <tr class="dark">
            <td>Event ID</td>
            <td colspan="6"><input type="int" name="event_id" placeholder="Enter Event_ID" required></td>
          </tr>
          <tr class="light">
            <td>Password</td>
            <td colspan="6"><input type="password" name="pass" placeholder="Password" required></td></tr>
	<tr>
        </tbody>
      </table>
      </td></tr>
     <tr>
	<td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	    <input type="image" src="images/enroll.png" alt="Submit" width="120" height="50" formaction="enrollreg.php">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		   <input type="image" src="images/reset1.png" alt="Submit" width="120" height="50"><br><br>
	</td>
     </tr>
    </table>
    </form>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col5">
  <div id="footer">
    <div id="newsletter">
      <h2>Stay In The Know !</h2>
      <p>Please enter your email to join our mailing list</p>
      <form action="#" method="post">
        <fieldset>
          <legend>News Letter</legend>
          <input type="text" value="Enter Email Here&hellip;"  onfocus="this.value=(this.value=='Enter Email Here&hellip;')? '' : this.value ;" />
          <input type="submit" name="news_go" id="news_go" value="GO" />
        </fieldset>
      </form>
    <!--  <p>To unsubscribe please <a href="#">click here &raquo;</a></p> -->
    </div>
    <div class="footbox">
      <h2>Police Station</h2>
      <ul>
        <li><a href="#">Address: MLA Rd, Kunnamangalam, Kerala 673571</a></li>
        <li><a href="#">Phone:0495 220 0256</a></li>
        <li class="last"><a href="#">http://www.kozhikodecitypolice.org</a></li>
      </ul>
    </div>
    <div class="footbox">
      <h2>Hospital</h2>
      <ul>
        <li><a href="#">KMCT MEDICAL COLLEGE HOSPITAL</a></li>
        <li><a href="#">MANASSERY-P.O, MUKKAM, KOZHIKODE</a></li>
        <li><a href="#">PH: 0495-2293500</a></li>
        <li><a href="#">Abulance PH:	0495-2295360</a></li>
      </ul>
    </div>
    <br class="clear" />
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper col6">
  <div id="copyright">
    <p class="fl_left">Copyright &copy; 2014 - All Rights Reserved - <a href="#">www.sac_nitc@nitc.ac.in</a></p>
   
    <br class="clear" />
  </div>
</div>
</body>
</html>
